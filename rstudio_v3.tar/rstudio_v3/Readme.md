### Requirements

 - Install [Docker](https://docs.docker.com/install)
 - Install [Docker Compose](https://docs.docker.com/compose/install)
 - Create `share` directory

```bash
mkdir -p share
```

### Build Docker image

```bash
docker-compose build
```

### Run Docker container

```bash
docker-compose up -d
```

Open http://localhost:8787 using the user `rstudio` and password `password`.

The `share` directory is shared with RStudio.

### Stop Docker container

```bash
docker-compose down
```

### Update Docker image
- Edit `provision.sh`
- Build Docker image
